/*
 * reader_writer.c
 * ---------------
 * A solution to the classic Readers-Writers problem using POSIX threads.
 *
 * Rules enforced:
 *   - Any number of readers may read the shared resource concurrently.
 *   - A writer gets exclusive access: no other reader or writer may be
 *     active while a writer is writing.
 *
 * This implementation uses the "readers-preference" (first readers-writers)
 * strategy built from two mutexes:
 *
 *   - rw_mutex  : held by a writer for the whole write, and by the *first*
 *                 reader to enter / *last* reader to leave. This is what
 *                 gives writers exclusive access with respect to readers.
 *   - count_mutex : protects the `reader_count` variable itself.
 *
 * Note: readers-preference can starve writers if readers keep arriving.
 * See the comment at the bottom for how to make it writer-preferring / fair.
 *
 * Build:  gcc -Wall -O2 -pthread reader_writer.c -o reader_writer
 * Run:    ./reader_writer
 */

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_READERS 5
#define NUM_WRITERS 2
#define NUM_ITERATIONS 3

/* The shared resource that readers read and writers modify. */
static int shared_data = 0;

/* reader_count = number of readers currently inside the critical section. */
static int reader_count = 0;

/* count_mutex protects reader_count.
 * rw_mutex gives a writer (or the group of readers) exclusive access. */
static pthread_mutex_t count_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t rw_mutex    = PTHREAD_MUTEX_INITIALIZER;

/* Small helper so the interleaving is visible when you run the program. */
static void tiny_sleep(void)
{
    usleep((useconds_t)(rand() % 100000)); /* up to 100 ms */
}

static void *reader(void *arg)
{
    long id = (long)arg;

    for (int i = 0; i < NUM_ITERATIONS; i++) {
        /* ---- Entry section ---- */
        pthread_mutex_lock(&count_mutex);
        reader_count++;
        if (reader_count == 1) {
            /* First reader locks out writers. Subsequent readers piggyback
             * on this lock and do not need to acquire rw_mutex themselves. */
            pthread_mutex_lock(&rw_mutex);
        }
        pthread_mutex_unlock(&count_mutex);

        /* ---- Critical section: reading (shared with other readers) ---- */
        printf("Reader  %ld reads  value = %d  (active readers: %d)\n",
               id, shared_data, reader_count);
        tiny_sleep();

        /* ---- Exit section ---- */
        pthread_mutex_lock(&count_mutex);
        reader_count--;
        if (reader_count == 0) {
            /* Last reader out lets writers back in. */
            pthread_mutex_unlock(&rw_mutex);
        }
        pthread_mutex_unlock(&count_mutex);

        tiny_sleep(); /* do something else before reading again */
    }
    return NULL;
}

static void *writer(void *arg)
{
    long id = (long)arg;

    for (int i = 0; i < NUM_ITERATIONS; i++) {
        /* ---- Entry section: acquire exclusive access ---- */
        pthread_mutex_lock(&rw_mutex);

        /* ---- Critical section: writing (exclusive) ---- */
        shared_data++;
        printf("Writer  %ld writes value = %d  (exclusive access)\n",
               id, shared_data);
        tiny_sleep();

        /* ---- Exit section ---- */
        pthread_mutex_unlock(&rw_mutex);

        tiny_sleep();
    }
    return NULL;
}

int main(void)
{
    pthread_t readers[NUM_READERS];
    pthread_t writers[NUM_WRITERS];

    srand((unsigned)time(NULL));

    printf("Starting %d readers and %d writers, %d iterations each.\n\n",
           NUM_READERS, NUM_WRITERS, NUM_ITERATIONS);

    for (long i = 0; i < NUM_WRITERS; i++)
        pthread_create(&writers[i], NULL, writer, (void *)(i + 1));

    for (long i = 0; i < NUM_READERS; i++)
        pthread_create(&readers[i], NULL, reader, (void *)(i + 1));

    for (int i = 0; i < NUM_READERS; i++)
        pthread_join(readers[i], NULL);

    for (int i = 0; i < NUM_WRITERS; i++)
        pthread_join(writers[i], NULL);

    printf("\nAll threads finished. Final value = %d\n", shared_data);

    pthread_mutex_destroy(&count_mutex);
    pthread_mutex_destroy(&rw_mutex);
    return 0;
}

/*
 * Making it fair / writer-preferring
 * ----------------------------------
 * The code above is readers-preference: as long as at least one reader is
 * inside, writers keep waiting, so a steady stream of readers starves writers.
 *
 * To avoid writer starvation, add a third lock (often called an "ordering" or
 * "turnstile" mutex) that every thread must pass through *before* the entry
 * section:
 *
 *     pthread_mutex_lock(&order_mutex);   // queue in arrival order
 *     ... existing entry section ...
 *     pthread_mutex_unlock(&order_mutex);
 *
 * Because a waiting writer sits in this queue, new readers line up behind it
 * instead of overtaking it, so the writer is served after the readers already
 * inside finish. This yields a fair, starvation-free solution.
 */
