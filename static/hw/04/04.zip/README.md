# Readers–Writers Problem — Homework

This folder contains a write-up and a working C solution for the classic
**Readers–Writers** synchronization problem.

## Contents

| File                         | Description                                               |
| ---------------------------- | --------------------------------------------------------- |
| `reader_writer_problem.md`   | The problem statement, rules, variants, and requirements. |
| `reader_writer.c`            | A pthreads solution (readers-preference) with comments.   |
| `README.md`                  | This file.                                                |

## Building

Requires GCC and the POSIX threads library (standard on Linux).

```sh
gcc -Wall -O2 -pthread reader_writer.c -o reader_writer
```

## Running

```sh
./reader_writer
```

You will see interleaved output from 5 readers and 2 writers. Note that:

- Several readers can be active at the same time
  (look for `active readers: N` where `N > 1`).
- A writer always prints `exclusive access` — no reader or other writer is
  active while it writes.

Example (abridged) output:

```
Reader  3 reads  value = 4  (active readers: 4)
Writer  1 writes value = 5  (exclusive access)
Writer  2 writes value = 6  (exclusive access)

All threads finished. Final value = 6
```

The final value equals `NUM_WRITERS * NUM_ITERATIONS` (here 2 × 3 = 6),
confirming that no writes were lost to a race.

## How the Solution Works

- A `count_mutex` protects a `reader_count`.
- The **first** reader to arrive acquires `rw_mutex`, and the **last** reader to
  leave releases it. This locks writers out for the whole time any readers are
  present, while letting readers run concurrently among themselves.
- A **writer** acquires `rw_mutex` directly, giving it exclusive access.

This is the *readers-preference* variant and can starve writers under a
continuous stream of readers. The bottom of `reader_writer.c` explains how to
extend it into a fair, starvation-free version. See `reader_writer_problem.md`
for the full background.
