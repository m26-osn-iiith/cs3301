// server.c
// UDP chatroom server.
// Since UDP has no real "connection", this server's client list
// IS the connection state - that's the main conceptual difference
// from a TCP server.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include "protocol.h"

typedef struct {
    struct sockaddr_in addr;
    char name[MAX_NAME];
    int active;
} client_t;

static client_t clients[MAX_CLIENTS];

// find a client by their address (their "identity" in UDP)
static int find_client(struct sockaddr_in *addr) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i].active &&
            clients[i].addr.sin_addr.s_addr == addr->sin_addr.s_addr &&
            clients[i].addr.sin_port == addr->sin_port) {
            return i;
        }
    }
    return -1;
}

static int add_client(struct sockaddr_in *addr, const char *name) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (!clients[i].active) {
            clients[i].active = 1;
            clients[i].addr = *addr;
            strncpy(clients[i].name, name, MAX_NAME - 1);
            return i;
        }
    }
    return -1; // full
}

static void remove_client(int idx) {
    clients[idx].active = 0;
}

// send a packet to every active client except exclude_idx (-1 = nobody excluded)
static void broadcast(int sockfd, packet_t *pkt, int exclude_idx) {
    for (int i = 0; i < MAX_CLIENTS; i++) {
        if (clients[i].active && i != exclude_idx) {
            sendto(sockfd, pkt, sizeof(*pkt), 0,
                   (struct sockaddr*)&clients[i].addr, sizeof(clients[i].addr));
        }
    }
}

static void system_announce(int sockfd, const char *text, int exclude_idx) {
    packet_t pkt = {0};
    pkt.type = MSG_CHAT;
    strncpy(pkt.name, "server", MAX_NAME - 1);
    strncpy(pkt.text, text, MAX_MSG - 1);
    broadcast(sockfd, &pkt, exclude_idx);
}

int main(void) {
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) { perror("socket"); exit(1); }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family      = AF_INET;
    server_addr.sin_port        = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("bind");
        exit(1);
    }

    printf("UDP chat server listening on port %d\n", PORT);

    while (1) {
        packet_t pkt;
        struct sockaddr_in from;
        socklen_t from_len = sizeof(from);

        ssize_t n = recvfrom(sockfd, &pkt, sizeof(pkt), 0,
                              (struct sockaddr*)&from, &from_len);
        if (n <= 0) continue;

        switch (pkt.type) {

            case MSG_DISCOVER: {
                // someone is looking for us - reply straight back to them
                packet_t reply = {0};
                reply.type = MSG_JOIN_OK;
                sendto(sockfd, &reply, sizeof(reply), 0,
                       (struct sockaddr*)&from, from_len);
                printf("[discovery] replied to %s:%d\n",
                       inet_ntoa(from.sin_addr), ntohs(from.sin_port));
                break;
            }

            case MSG_JOIN: {
                int idx = add_client(&from, pkt.name);
                if (idx >= 0) {
                    printf("[join] %s\n", pkt.name);
                    char msg[64];
                    snprintf(msg, sizeof(msg), "%s joined the chat", pkt.name);
                    system_announce(sockfd, msg, idx);
                } else {
                    printf("[join] rejected %s, server full\n", pkt.name);
                }
                break;
            }

            case MSG_CHAT: {
                int idx = find_client(&from);
                if (idx >= 0) {
                    printf("%s: %s\n", clients[idx].name, pkt.text);
                    broadcast(sockfd, &pkt, idx);
                }
                break;
            }

            case MSG_LEAVE: {
                int idx = find_client(&from);
                if (idx >= 0) {
                    printf("[leave] %s\n", clients[idx].name);
                    char msg[64];
                    snprintf(msg, sizeof(msg), "%s left the chat", clients[idx].name);
                    remove_client(idx);
                    system_announce(sockfd, msg, -1);
                }
                break;
            }

            default:
                break; // ignore anything unrecognized
        }
    }

    close(sockfd);
    return 0;
}
