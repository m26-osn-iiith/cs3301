#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdint.h>

#define PORT        9000
#define MAX_NAME    32
#define MAX_MSG     200
#define MAX_CLIENTS 32

// message types - the first byte of every packet says what kind it is
typedef enum {
    MSG_DISCOVER = 1,  // client -> server : "who's out there?"
    MSG_JOIN_OK  = 2,  // server -> client : "found me, here's confirmation"
    MSG_JOIN     = 3,  // client -> server : "I'm joining, here's my name"
    MSG_CHAT     = 4,  // both directions  : chat text
    MSG_LEAVE    = 5   // client -> server : "I'm leaving"
} msg_type_t;

// every packet on the wire has this exact shape
typedef struct {
    uint8_t type;
    char    name[MAX_NAME];  // sender's name
    char    text[MAX_MSG];   // used for chat messages
} packet_t;

#endif
