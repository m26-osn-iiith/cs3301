// client.c
// UDP chatroom client.
// Finds the server via broadcast discovery, then joins and chats.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/select.h>
#include "protocol.h"

static int sockfd;
static struct sockaddr_in server_addr;
static char my_name[MAX_NAME];

// broadcast a DISCOVER packet on the LAN and wait for the server to reply.
// this is how the client learns the server's IP without being told it.
static void discover_server(void) {
    int enable = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &enable, sizeof(enable));

    struct sockaddr_in bcast_addr;
    memset(&bcast_addr, 0, sizeof(bcast_addr));
    bcast_addr.sin_family      = AF_INET;
    bcast_addr.sin_port        = htons(PORT);
    bcast_addr.sin_addr.s_addr = INADDR_BROADCAST; // 255.255.255.255

    packet_t pkt = {0};
    pkt.type = MSG_DISCOVER;

    // 1 second timeout so we can retry the broadcast if nobody answers yet
    struct timeval tv = {1, 0};
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    printf("Looking for server...\n");

    while (1) {
        sendto(sockfd, &pkt, sizeof(pkt), 0,
               (struct sockaddr*)&bcast_addr, sizeof(bcast_addr));

        packet_t reply;
        struct sockaddr_in from;
        socklen_t from_len = sizeof(from);
        ssize_t n = recvfrom(sockfd, &reply, sizeof(reply), 0,
                              (struct sockaddr*)&from, &from_len);

        if (n > 0 && reply.type == MSG_JOIN_OK) {
            server_addr = from; // the actual server's real address
            printf("Found server at %s:%d\n",
                   inet_ntoa(from.sin_addr), ntohs(from.sin_port));
            return;
        }
        // timed out - loop and broadcast again
    }
}

static void send_join(void) {
    packet_t pkt = {0};
    pkt.type = MSG_JOIN;
    strncpy(pkt.name, my_name, MAX_NAME - 1);
    sendto(sockfd, &pkt, sizeof(pkt), 0,
           (struct sockaddr*)&server_addr, sizeof(server_addr));
}

static void send_leave(void) {
    packet_t pkt = {0};
    pkt.type = MSG_LEAVE;
    strncpy(pkt.name, my_name, MAX_NAME - 1);
    sendto(sockfd, &pkt, sizeof(pkt), 0,
           (struct sockaddr*)&server_addr, sizeof(server_addr));
}

// watch stdin (typing) and the socket (incoming messages) at the same time
static void chat_loop(void) {
    struct timeval tv = {0, 0}; // no timeout needed anymore
    setsockopt(sockfd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

    printf("Connected. Type a message and hit enter. Ctrl+C to quit.\n");

    fd_set readfds;
    while (1) {
        FD_ZERO(&readfds);
        FD_SET(STDIN_FILENO, &readfds);
        FD_SET(sockfd, &readfds);
        int maxfd = sockfd > STDIN_FILENO ? sockfd : STDIN_FILENO;

        select(maxfd + 1, &readfds, NULL, NULL, NULL);

        if (FD_ISSET(STDIN_FILENO, &readfds)) {
            char line[MAX_MSG];
            if (fgets(line, sizeof(line), stdin) == NULL) break;
            line[strcspn(line, "\n")] = 0; // strip trailing newline

            packet_t pkt = {0};
            pkt.type = MSG_CHAT;
            strncpy(pkt.name, my_name, MAX_NAME - 1);
            strncpy(pkt.text, line, MAX_MSG - 1);
            sendto(sockfd, &pkt, sizeof(pkt), 0,
                   (struct sockaddr*)&server_addr, sizeof(server_addr));
        }

        if (FD_ISSET(sockfd, &readfds)) {
            packet_t pkt;
            struct sockaddr_in from;
            socklen_t from_len = sizeof(from);
            ssize_t n = recvfrom(sockfd, &pkt, sizeof(pkt), 0,
                                  (struct sockaddr*)&from, &from_len);
            if (n > 0 && pkt.type == MSG_CHAT) {
                printf("%s: %s\n", pkt.name, pkt.text);
            }
        }
    }
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("Usage: %s <your_name>\n", argv[0]);
        return 1;
    }
    strncpy(my_name, argv[1], MAX_NAME - 1);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) { perror("socket"); exit(1); }

    discover_server();
    send_join();
    chat_loop();
    send_leave();

    close(sockfd);
    return 0;
}
