/* race_counter.c — DEMO 1: two threads, one unguarded counter.
 *
 *   make race_counter
 *   for i in 1 2 3 4 5; do ./race_counter; done
 *
 * Expected output: 2000000. You will not get it.
 *
 * If your machine is too fast to show the race reliably, try:
 *   taskset -c 0,1 ./race_counter      # pin both threads to two cores
 *   ITERATIONS at 10000000 below       # widen the window
 *
 * And then, for the punchline about testing:
 *   make race_counter.O2 && ./race_counter.O2
 * At -O2 the compiler can keep the counter in a register for the whole
 * loop, and the race disappears. The code did not get more correct.
 *
 * To see the race named explicitly, with both stack traces:
 *   sudo sysctl vm.mmap_rnd_bits=28
 *   make race_counter.tsan && ./race_counter.tsan
 */
#include <pthread.h>
#include <stdio.h>

#define ITERATIONS 1000000
#define THREADS    2

long counter = 0;          

static void *bump(void *arg)
{
    (void)arg;
    for (int i = 0; i < ITERATIONS; i++)
        counter++;         
    return NULL;
}

int main(void)
{
    pthread_t tid[THREADS];

    for (int i = 0; i < THREADS; i++)
        if (pthread_create(&tid[i], NULL, bump, NULL) != 0) {
            fprintf(stderr, "pthread_create failed\n");
            return 1;
        }

    for (int i = 0; i < THREADS; i++)
        pthread_join(tid[i], NULL);

    long expected = (long)THREADS * ITERATIONS;
    printf("expected %ld   got %ld   lost %ld\n",
           expected, counter, expected - counter);
    return 0;
}
