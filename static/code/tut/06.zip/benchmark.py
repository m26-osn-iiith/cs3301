#!/usr/bin/env python3
"""Benchmark array_sum across thread counts and plot time vs. threads.

Compiles array_sum.c, runs it for several thread counts (averaging a few
repeats each), then writes a PNG graph of elapsed time and speedup.
"""
import os
import subprocess
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "array_sum.c")
BIN = os.path.join(HERE, "array_sum")

ARRAY_SIZE = 200_000_000      # 200M longs ~ 1.6 GB
THREAD_COUNTS = [1, 2, 3, 4, 6, 8, 10, 12, 16]
REPEATS = 3


def compile_program():
    print("Compiling array_sum.c ...")
    subprocess.run(
        ["gcc", "-O2", "-pthread", SRC, "-o", BIN],
        check=True,
    )


def run(nthreads):
    """Return the best (minimum) elapsed time over REPEATS runs."""
    best = None
    total = None
    for _ in range(REPEATS):
        out = subprocess.run(
            [BIN, str(nthreads), str(ARRAY_SIZE)],
            check=True, capture_output=True, text=True,
        ).stdout.split()
        elapsed = float(out[1])
        total = int(out[2])
        best = elapsed if best is None else min(best, elapsed)
    return best, total


def main():
    compile_program()

    threads, times = [], []
    expected = None
    for nt in THREAD_COUNTS:
        elapsed, total = run(nt)
        if expected is None:
            expected = total
        ok = "ok" if total == expected else "MISMATCH"
        threads.append(nt)
        times.append(elapsed)
        print(f"  {nt:2d} threads: {elapsed:.4f} s  (sum={total}, {ok})")

    base = times[0]  # single-thread time, for speedup
    speedup = [base / t for t in times]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    ax1.plot(threads, times, "o-", color="#2563eb", linewidth=2, markersize=7)
    ax1.set_title("Time taken vs. number of threads")
    ax1.set_xlabel("Number of threads")
    ax1.set_ylabel("Elapsed time (seconds)")
    ax1.grid(True, alpha=0.3)
    ax1.set_xticks(threads)

    ax2.plot(threads, speedup, "o-", color="#16a34a", linewidth=2,
             markersize=7, label="Measured speedup")
    ax2.plot(threads, threads, "--", color="#9ca3af", label="Ideal (linear)")
    ax2.set_title("Speedup vs. number of threads")
    ax2.set_xlabel("Number of threads")
    ax2.set_ylabel("Speedup (T1 / Tn)")
    ax2.grid(True, alpha=0.3)
    ax2.set_xticks(threads)
    ax2.legend()

    fig.suptitle(f"Parallel sum of {ARRAY_SIZE:,} longs "
                 f"({ARRAY_SIZE * 8 / 1e9:.1f} GB)", fontsize=13)
    fig.tight_layout()
    out_png = os.path.join(HERE, "threads_vs_time.png")
    fig.savefig(out_png, dpi=120)
    print(f"\nSaved graph to {out_png}")


if __name__ == "__main__":
    sys.exit(main())
