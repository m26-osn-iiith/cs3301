/*
 * array_sum.c — Multithreaded sum of a very big array using POSIX threads.
 *
 * Each thread sums a contiguous slice of the array. The slices are disjoint,
 * so no locking is needed: each thread writes only to its own partial-sum slot
 * and the main thread adds them up after joining.
 *
 * Usage:   ./array_sum <num_threads> [array_size]
 * Example: ./array_sum 4 100000000
 *
 * Prints one line:  <num_threads> <elapsed_seconds> <sum>
 */

#define _POSIX_C_SOURCE 199309L
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <time.h>

typedef struct {
    const long *data;   /* array to sum                         */
    size_t      start;  /* first index this thread handles      */
    size_t      end;    /* one past the last index              */
    long long   sum;    /* partial result, written by this thread only */
} Task;

static void *worker(void *arg) {
    Task *t = (Task *)arg;
    long long s = 0;
    for (size_t i = t->start; i < t->end; i++)
        s += t->data[i];
    t->sum = s;
    return NULL;
}

/* Monotonic wall-clock time in seconds. */
static double now_seconds(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        fprintf(stderr, "usage: %s <num_threads> [array_size]\n", argv[0]);
        return 1;
    }

    int    nthreads = atoi(argv[1]);
    size_t n        = (argc >= 3) ? strtoull(argv[2], NULL, 10) : 200000000UL;

    if (nthreads < 1) nthreads = 1;
    if ((size_t)nthreads > n) nthreads = (int)n;

    long *data = malloc(n * sizeof(long));
    if (!data) {
        fprintf(stderr, "error: could not allocate %zu longs\n", n);
        return 1;
    }

    /* Fill with a known pattern so the result is verifiable:
     * data[i] = i % 7, which keeps values small and the sum exact. */
    for (size_t i = 0; i < n; i++)
        data[i] = (long)(i % 7);

    pthread_t *threads = malloc(nthreads * sizeof(pthread_t));
    Task      *tasks   = malloc(nthreads * sizeof(Task));

    size_t chunk = n / nthreads;

    double t0 = now_seconds();

    for (int k = 0; k < nthreads; k++) {
        tasks[k].data  = data;
        tasks[k].start = (size_t)k * chunk;
        /* Last thread absorbs any remainder from an uneven division. */
        tasks[k].end   = (k == nthreads - 1) ? n : (size_t)(k + 1) * chunk;
        tasks[k].sum   = 0;
        pthread_create(&threads[k], NULL, worker, &tasks[k]);
    }

    long long total = 0;
    for (int k = 0; k < nthreads; k++) {
        pthread_join(threads[k], NULL);
        total += tasks[k].sum;
    }

    double elapsed = now_seconds() - t0;

    /* stdout: machine-readable line for the plotting script. */
    printf("%d %.6f %lld\n", nthreads, elapsed, total);

    free(data);
    free(threads);
    free(tasks);
    return 0;
}
