/* producer_consumer.c — a bounded buffer with one mutex and two condvars.
 *
 *   make producer_consumer
 *   ./producer_consumer                 # 2 producers, 2 consumers, 20 items each
 *   ./producer_consumer P C ITEMS       # P producers, C consumers, ITEMS each
 */
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N 8                                  /* buffer slots */

static int buf[N];
static int count = 0, head = 0, tail = 0;    /* all guarded by m */

static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t not_full  = PTHREAD_COND_INITIALIZER;   /* count < N */
static pthread_cond_t not_empty = PTHREAD_COND_INITIALIZER;   /* count > 0 */

struct task { long id; int n; };

static void *producer(void *arg)
{
    struct task *t = arg;

    for (int i = 0; i < t->n; i++) {
        int item = (int)(t->id * 1000 + i);

        pthread_mutex_lock(&m);
        while (count == N)                   /* wait until there is room */
            pthread_cond_wait(&not_full, &m);

        buf[tail] = item;
        tail = (tail + 1) % N;
        count++;
        printf("producer %ld  put %5d    count=%d\n", t->id, item, count);

        pthread_cond_signal(&not_empty);     /* a slot is now available */
        pthread_mutex_unlock(&m);
    }
    return NULL;
}

static void *consumer(void *arg)
{
    struct task *t = arg;

    for (int i = 0; i < t->n; i++) {
        pthread_mutex_lock(&m);
        while (count == 0)                   /* wait until there is an item */
            pthread_cond_wait(&not_empty, &m);

        int item = buf[head];
        head = (head + 1) % N;
        count--;
        printf("consumer %ld  got %5d    count=%d\n", t->id, item, count);

        pthread_cond_signal(&not_full);      /* a slot is now free */
        pthread_mutex_unlock(&m);
    }
    return NULL;
}

int main(int argc, char **argv)
{
    int n_producers = (argc > 1) ? atoi(argv[1]) : 2;
    int n_consumers = (argc > 2) ? atoi(argv[2]) : 2;
    int items_each  = (argc > 3) ? atoi(argv[3]) : 20;

    if (n_producers < 1 || n_consumers < 1 || items_each < 1) {
        fprintf(stderr, "usage: %s [producers] [consumers] [items_each]\n",
                argv[0]);
        return 2;
    }

    int total = n_producers * items_each;
    printf("buffer %d slots · %d producers · %d consumers · %d items each\n\n",
           N, n_producers, n_consumers, items_each);

    pthread_t   *pt = calloc((size_t)n_producers, sizeof *pt);
    pthread_t   *ct = calloc((size_t)n_consumers, sizeof *ct);
    struct task *pa = calloc((size_t)n_producers, sizeof *pa);
    struct task *ca = calloc((size_t)n_consumers, sizeof *ca);
    if (!pt || !ct || !pa || !ca) { fprintf(stderr, "out of memory\n"); return 1; }

    for (int i = 0; i < n_producers; i++) {
        pa[i].id = i + 1;
        pa[i].n  = items_each;
        pthread_create(&pt[i], NULL, producer, &pa[i]);
    }

    /* split the total across consumers so they take exactly `total` items */
    for (int i = 0; i < n_consumers; i++) {
        ca[i].id = i + 1;
        ca[i].n  = total / n_consumers + (i < total % n_consumers ? 1 : 0);
        pthread_create(&ct[i], NULL, consumer, &ca[i]);
    }

    for (int i = 0; i < n_producers; i++) pthread_join(pt[i], NULL);
    for (int i = 0; i < n_consumers; i++) pthread_join(ct[i], NULL);

    printf("\ndone — %d items through the buffer, count left at %d\n",
           total, count);

    free(pt); free(ct); free(pa); free(ca);
    return 0;
}
