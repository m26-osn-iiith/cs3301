/* counter_fixed.c — the same counter, fixed three ways, timed.
 *
 *   make counter_fixed
 *   ./counter_fixed inner     # mutex around each increment
 *   ./counter_fixed outer     # mutex around the whole loop
 *   ./counter_fixed atomic    # no mutex at all
 *
 * All three print the right answer every time. Run all three before the
 * tutorial and write the times into the [    ] boxes on the
 * "Three correct fixes" slide.
 *
 * The one to talk about is "outer": it is correct, it is the fastest, and
 * it has destroyed the entire point of using threads. No test can tell
 * you that.
 */
#include <pthread.h>
#include <stdatomic.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define ITERATIONS 1000000
#define THREADS    2

enum mode { INNER, OUTER, ATOMIC };
static enum mode mode;

static long            plain_counter  = 0;   /* guarded by m */
static _Atomic long    atomic_counter = 0;   /* guarded by the hardware */
static pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;

static void *bump(void *arg)
{
    (void)arg;

    switch (mode) {
    case INNER:
        /* 2 000 000 lock/unlock pairs, nearly all of them contended */
        for (int i = 0; i < ITERATIONS; i++) {
            pthread_mutex_lock(&m);
            plain_counter++;
            pthread_mutex_unlock(&m);
        }
        break;

    case OUTER:
        /* correct, fastest, and completely serial */
        pthread_mutex_lock(&m);
        for (int i = 0; i < ITERATIONS; i++)
            plain_counter++;
        pthread_mutex_unlock(&m);
        break;

    case ATOMIC:
        /* one lock-prefixed instruction per increment; no syscall */
        for (int i = 0; i < ITERATIONS; i++)
            atomic_counter++;
        break;
    }
    return NULL;
}

static double now_ms(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1000000.0;
}

int main(int argc, char **argv)
{
    const char *name = (argc > 1) ? argv[1] : "inner";

    if      (strcmp(name, "inner")  == 0) mode = INNER;
    else if (strcmp(name, "outer")  == 0) mode = OUTER;
    else if (strcmp(name, "atomic") == 0) mode = ATOMIC;
    else {
        fprintf(stderr, "usage: %s inner|outer|atomic\n", argv[0]);
        return 2;
    }

    pthread_t tid[THREADS];
    double t0 = now_ms();

    for (int i = 0; i < THREADS; i++)
        pthread_create(&tid[i], NULL, bump, NULL);
    for (int i = 0; i < THREADS; i++)
        pthread_join(tid[i], NULL);

    double elapsed = now_ms() - t0;
    long got = (mode == ATOMIC) ? (long)atomic_counter : plain_counter;

    printf("%-7s  got %ld   expected %ld   %7.1f ms\n",
           name, got, (long)THREADS * ITERATIONS, elapsed);
    return 0;
}
