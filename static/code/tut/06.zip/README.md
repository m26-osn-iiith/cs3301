# Concurrency tutorial — demo code

Companion code for the Concurrency tutorial (OS & Networks). Everything here
was built and run on this machine; the measured results are recorded below so
you know what to expect before you stand up.

```bash
make all             # the four working programs
```

Builds clean with `-Wall -Wextra`, no warnings.

---

## Demo 1 — the race (slides: "Two threads, one counter", "A race condition")

```bash
for i in 1 2 3 4 5; do ./race_counter; done
```

Measured here — five runs, five wrong answers, every one low:

```
expected 2000000   got 1023310   lost 976690
expected 2000000   got 1046504   lost 953496
expected 2000000   got 1059282   lost 940718
expected 2000000   got 1148320   lost 851680
expected 2000000   got 1053785   lost 946215
```

Reproduces reliably as shipped — no `taskset` needed on this machine. If the
machine you present on keeps printing 2000000, pin the threads with
`taskset -c 0,1 ./race_counter` or raise `ITERATIONS` to 10000000.

Then the mechanism:

```bash
make asm             # the body of bump(), directives stripped
```

The three instructions are in the middle, exactly as the slide shows them:

```
movq    counter(%rip), %rax
addq    $1, %rax
movq    %rax, counter(%rip)
```

And the punchline about testing:

```bash
make race_counter.O2 && ./race_counter.O2    # the race can vanish entirely
```

## The three fixes (slide: "Three correct fixes. Measure them.")

```bash
./counter_fixed inner    # mutex around each increment
./counter_fixed outer    # mutex around the whole loop
./counter_fixed atomic   # _Atomic long, no mutex
```

Measured here (these numbers are already on the slide — re-run and update
them if you present on a different machine):

```
inner    got 2000000   expected 2000000     177.9 ms
outer    got 2000000   expected 2000000      17.8 ms
atomic   got 2000000   expected 2000000      63.5 ms
```

All three are correct. `inner` locks around every increment (2,000,000
contended lock/unlock pairs) and is slowest. `atomic` drops the mutex for a
single lock-prefixed instruction per increment — faster, but the two cores
still bounce `counter`'s cache line back and forth. `outer` takes the lock
once per thread and is ~10x faster than `inner` — because each thread runs its
whole loop while the other is blocked, so the program is now entirely serial.
It has destroyed the point of using threads, and no test can tell you that.

---

## Demo 2 — producer/consumer (slides: "the problem", "the solution")

```bash
./producer_consumer                      # 2 producers, 2 consumers, 20 each
./producer_consumer 4 1 30               # P producers, C consumers, ITEMS each
```

A bounded buffer of 8 slots, guarded by one mutex and two condition
variables: producers wait on `not_full` when the buffer is full, consumers
wait on `not_empty` when it is empty, and each side signals the other after
updating `count`. Both waits use `while` (not `if`) so the predicate is
re-checked after every wakeup — the one thing that makes the wait correct
under every legal condvar implementation. Runs to completion with every item
passing through the buffer and `count` left at 0.

---

## Demo 3 — deadlock (slides: "Deadlock", "Two locks, two orders, one hang")

```bash
./deadlock &           # hangs almost at once; prints its pid and both addresses
top -H                 # 0% CPU
gdb -p $(pgrep deadlock)
(gdb) thread apply all bt
(gdb) quit
./deadlock fixed       # runs to completion
```

Verified: unfixed hangs every time, `./deadlock fixed` prints
`t1 finished / t2 finished / both threads finished` and exits 0.

**Check this before the tutorial.** On many distributions `ptrace_scope`
stops gdb attaching to a process it did not start:

```bash
sudo sysctl -w kernel.yama.ptrace_scope=0
```

Otherwise run under gdb from the start and interrupt with Ctrl-C.

---

## ThreadSanitizer (slide: "The tools that see what you cannot")

```bash
make tsan
make run-tsan          # demo 1's counter
```

`run-tsan` output names the variable and both sides of the race:

```
WARNING: ThreadSanitizer: data race
  #0 bump race_counter.c:...
  Location is global 'counter' of size 8
```

**Known problem on this laptop.** Running `./race_counter.tsan` directly dies
with:

```
FATAL: ThreadSanitizer: unexpected memory mapping
```

That is not your bug. Recent kernels randomise mmap with more entropy than
TSan's shadow-memory layout expects. The `run-tsan` targets work around it
with `setarch $(uname -m) -R`, which disables ASLR for that one process and
needs no root. The sudo alternative is `sysctl -w vm.mmap_rnd_bits=28`.

**Use the make targets in front of the class.** Run the binaries directly and
you will hit the error live.

---

## Everything at a glance

| Target | What it is for |
| --- | --- |
| `make all` | the four working programs |
| `make tsan` | ThreadSanitizer build |
| `make run-tsan` | run it with the ASLR workaround |
| `make asm` | the three instructions behind `counter++` |
| `make race_counter.O2` | the race disappearing under optimisation |
| `make clean` | remove every binary |
