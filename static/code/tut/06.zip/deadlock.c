/* deadlock.c — DEMO 3: two mutexes taken in opposite orders.
 *
 *   make deadlock
 *   ./deadlock &            # hangs almost immediately; prints its pid
 *   top -H                  # 0% CPU — it is stopped, not spinning
 *   gdb -p $(pgrep deadlock)
 *   (gdb) thread apply all bt
 *   (gdb) quit
 *
 * Both threads will be parked in __lll_lock_wait under pthread_mutex_lock,
 * and the frame above each one names the line of YOUR code that asked for
 * the lock. That is the cycle, read off a live process.
 *
 * Then the fix:
 *   ./deadlock fixed        # runs to completione
 *
 * NOTE BEFORE THE TUTORIAL: on many Linux distributions ptrace_scope stops
 * gdb attaching to a process it did not start. Test it first. If blocked:
 *   sudo sysctl -w kernel.yama.ptrace_scope=0
 * or run under gdb from the start and interrupt with Ctrl-C.
 */
#include <pthread.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define ROUNDS 100000

static pthread_mutex_t m1 = PTHREAD_MUTEX_INITIALIZER;
static pthread_mutex_t m2 = PTHREAD_MUTEX_INITIALIZER;

static int use_ordering = 0;

/* Take both mutexes in one global order — here, by address.
 * Any total order works; the addresses are an order you already have,
 * with no registry and no numbering convention to maintain. */
static void lock_both(pthread_mutex_t *a, pthread_mutex_t *b)
{
    if (a > b) { pthread_mutex_t *t = a; a = b; b = t; }
    pthread_mutex_lock(a);
    pthread_mutex_lock(b);
}

static void *t1(void *arg)
{
    (void)arg;
    for (int i = 0; i < ROUNDS; i++) {
        if (use_ordering) {
            lock_both(&m1, &m2);
        } else {
            pthread_mutex_lock(&m1);
            usleep(100);                 /* widen the window on purpose */
            pthread_mutex_lock(&m2);     /* <-- HANGS HERE */
        }
        pthread_mutex_unlock(&m2);
        pthread_mutex_unlock(&m1);
    }
    printf("t1 finished\n");
    return NULL;
}

static void *t2(void *arg)
{
    (void)arg;
    for (int i = 0; i < ROUNDS; i++) {
        if (use_ordering) {
            lock_both(&m2, &m1);         /* asks the other way round; still ordered */
        } else {
            pthread_mutex_lock(&m2);     /* the opposite order — this is the bug */
            usleep(100);
            pthread_mutex_lock(&m1);     /* <-- HANGS HERE */
        }
        pthread_mutex_unlock(&m1);
        pthread_mutex_unlock(&m2);
    }
    printf("t2 finished\n");
    return NULL;
}

int main(int argc, char **argv)
{
    use_ordering = (argc > 1 && strcmp(argv[1], "fixed") == 0);

    printf("pid %d — lock ordering %s\n",
           (int)getpid(),
           use_ordering ? "ON (will finish)" : "OFF (will hang)");
    printf("m1 at %p, m2 at %p\n\n", (void *)&m1, (void *)&m2);

    pthread_t a, b;
    pthread_create(&a, NULL, t1, NULL);
    pthread_create(&b, NULL, t2, NULL);
    pthread_join(a, NULL);
    pthread_join(b, NULL);

    printf("both threads finished\n");
    return 0;
}
