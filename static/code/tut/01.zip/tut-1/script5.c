#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int fd[2];
    pipe(fd);

    if (fork() == 0) {
        close(fd[0]);

        dup2(fd[1], STDOUT_FILENO);
        close(fd[1]);

        printf("hello through pipe\n");
        return 0;
    }

    close(fd[1]);

    char buf[100];
    int n = read(fd[0], buf, sizeof(buf)-1);
    buf[n] = '\0';

    printf("Parent received: %s", buf);

    close(fd[0]);
    wait(NULL);
}