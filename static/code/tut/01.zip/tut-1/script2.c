#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        printf("Child exiting with 42\n");
        return 42;
    }

    int status;
    pid_t w = wait(&status);  //waitpid to wait for a specific child

    printf("Collected child %d\n", w);

    if (WIFEXITED(status))
        printf("Normal exit, status=%d\n", WEXITSTATUS(status));

    return 0;
}


/*
    WIFEXITED(status)  - was it a normal exit? return from main/exit()
    WEXITSTATUS(status) - whats the exit code?
    WIFSIGNALED(status) - was it killed by a signal?
    WTERMSIG(status) - which signal 
*/