#include <stdio.h>
#include <unistd.h>

int main() {
    int x = 10;

    pid_t pid = fork();

    if (pid == 0) {
        printf("CHILD : fork returned %d, mypid=%d, x=%d\n",
               pid, getpid(), x);
        x=20;
    } else {
        printf("PARENT: fork returned %d, mypid=%d, x=%d\n",
               pid, getpid(), x);
    }

    return 0;
}