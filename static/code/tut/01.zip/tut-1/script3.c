#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        printf("Child before exec: pid=%d\n", getpid());

        char *args[] = {"echo", "hello from exec", NULL};
        execvp("echo", args);

        perror("execvp");
        _exit(1);
    }

    wait(NULL);
    printf("Parent done\n");
    return 0;
}