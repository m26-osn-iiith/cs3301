#include <stdio.h>
#include <unistd.h>

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        printf("Child exiting\n");
        return 0;
    }

    printf("Parent sleeping for 20 seconds. Check ps.\n");
    sleep(5);

    return 0;
}

// ps -o pid,ppid,state,cmd | grep script4